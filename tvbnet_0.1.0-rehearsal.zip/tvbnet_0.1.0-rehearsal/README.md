# tvbnet 0.1.0-rehearsal

Synthetic threat–vulnerability–barrier dataset and executable validation pipeline for multilayer
security and cost–risk trade-offs in data transmission networks.

**SYNTHETIC REHEARSAL — no row is an operational measurement.**

License: Creative Commons Attribution 4.0 International (CC BY 4.0)

Predecessor record: https://doi.org/10.5281/zenodo.22166893

## Package Layout

```
tvbnet_0.1.0-rehearsal/
├── README.md                         ← this file
├── code/
│   ├── requirements.txt              ← Python dependencies
│   ├── config/pipeline.yaml          ← all design assumptions
│   ├── src/tvbnet/                   ← 9 modules: design, generate, engine, pipeline, validate, release, package, cli
│   ├── tests/test_tvbnet.py          ← 25 test cases
│   └── scripts/figures.py            ← 13 figures, 300 DPI
├── dataset/
│   ├── tables/                       ← 10 Parquet tables (scenarios, networks, nodes, links, assets,
│   │                                    vulnerabilities, threats, barriers, configurations, frontier)
│   ├── splits/                       ← 5 leakage-audited evaluation manifests
│   ├── docs/data_dictionary.csv      ← column metadata generated from the schema
│   ├── metadata/datacite.json        ← DataCite metadata with IsDerivedFrom relation
│   ├── metadata/provenance.jsonld    ← object-level PROV-O lineage
│   ├── ro-crate-metadata.json        ← RO-Crate 1.1 description
│   └── checksums_sha256.txt          ← detached SHA-256 manifest
├── report/
│   ├── validation_report.json        ← all gate outcomes, defect detection, analyses
│   ├── cascades.json                 ← layer cascade data
│   └── example_scenario.json         ← worked example data
├── figures/                          ← 13 figures (fig01–fig13, 300 DPI PNG)
└── notebook/
    └── tvbnet_demo.ipynb             ← Google Colab demonstration notebook
```

## Reproduce

```bash
pip install -r code/requirements.txt
PYTHONPATH=code/src python -m pytest code/tests -q                        # 25 test cases
PYTHONPATH=code/src python -m tvbnet.cli all --config code/config/pipeline.yaml --out build
python code/scripts/figures.py                                            # 13 figures, 300 DPI
cd dataset && sha256sum -c checksums_sha256.txt
```

## Interactive Demo

Open `notebook/tvbnet_demo.ipynb` in Google Colab for a guided demonstration:

1. Dataset structure — loading and inspecting the 10 canonical tables
2. Scenario design — L9(3⁴) orthogonal array and factor balance
3. Network generation — six topology families
4. Risk engine — threat–vulnerability–barrier model (Equations 1–11)
5. Configuration selection — exact optimum, greedy, heuristics, Pareto frontiers
6. Input-information reliability — regret and budget overruns
7. Technical validation — defect injection, detection, and release gates
8. Conclusions

## Key Numbers

| Metric | Value |
|--------|-------|
| Scenarios | 2,592 |
| Design cells | 1,296 |
| Canonical tables | 10 |
| Total records | 346,000+ |
| Barrier subsets enumerated | 24,261,120 |
| Injected defects detected | 125/125 (0 false positives) |
| Release gates passed | 17/17 |
| Max recomputation error | 5.1 × 10⁻¹⁶ |
| Manifest leakage violations | 0 |

## Citation

Torstensson, O.; Prokopovych-Tkachenko, D.; Magro, V.; Yakovenko, V.; Aleksieiev, O.
tvbnet 0.1.0-Rehearsal: A Reproducible Synthetic Dataset and Executable Validation Pipeline
for Multilayer Security and Cost–Risk Trade-Offs in Data Transmission Networks.
*Data Descriptor*, 2026.
