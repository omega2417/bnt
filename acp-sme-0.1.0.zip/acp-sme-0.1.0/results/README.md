# Pre-generated results

These files are the output of `acp-sme reproduce --daily` on CPython 3.11 (Linux), included
so that a reader can inspect the reported numbers without running anything. Regenerating
them overwrites this directory:

```bash
acp-sme reproduce --daily
```

| File | Contents |
| --- | --- |
| `primary_summary.json` | Table 6: means, 95% confidence intervals, paired differences, design totals |
| `trace_outcomes.csv` | One row per trace per condition — 90 traces × 3 conditions = 270 rows |
| `daily_coverage.csv` | Per-day modeled coverage for every trace and condition (32,400 rows) |
| `sensitivity.csv` | Table 7: 5 thresholds × 3 budget factors, with observed and analytically expected false alerts |
| `parameters.json` | Every parameter pack, machine-readable (`acp-sme params`) |
| `run_environment.json` | Python version, implementation and platform of the run |
| `figures/` | Figures 3–6 |

All values are **synthetic model output**. No real enterprise, employee, customer, supplier
or incident is represented. See `../docs/CLAIMS_BOUNDARY.md` for what each number does and
does not support, and `../docs/REPRODUCIBILITY.md` for the comparison against the values
reported in the article.
