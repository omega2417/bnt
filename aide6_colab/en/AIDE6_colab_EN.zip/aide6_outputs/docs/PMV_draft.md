# Test programme and procedure (TP) for the prototype

> **DRAFT** by agent D (AIDE-6), 2026-11-05T00:08:14+00:00. Requires editing and approval by a human.

- T1 base motion isolation
- T1b gyro noise
- T2 mounting angles
- T3 blockage during a turn
- T4 reproduction of scenario C
- T5 thermal axis shift
- T6 factorial design 2^(4−1)
- T7 telemetry + anomaly detection

Order: T1b, T2 (calibration) → T1 → T3–T7.

Measurement uncertainty (GUM): u_c = 0.0056°, U(95 %) = 0.0124° (k = 2.20).
