
### 1. Stage-wise use of AI with gates yields a justified narrowing of the solution space (RQ1)
* Space **4608 → 1476 compatible → 810 feasible → 42 on the Pareto front → 8 twins → 1 prototype**.
  Every transition is a gate decision with criteria, recorded in the log (10 decisions, $T_{cov}$ = 1 at G3, G5, G6).
* The number of compatible configurations was independently reproduced by the critic (formula $n_1n_7(15+3\cdot36)$ = 1476).
* NSGA-II recovered the exact front in 10/10 runs using 41% of the evaluations of the compatible space
  (random search: 94.8%). Target H3 (≤ 35 %) **was not met** in our teaching model — NSGA-II tuning or a hybrid with BO is needed (LS3 plan).
* The TOPSIS leader is **bbacaba** (Single-antenna GNSS/INS; MEMS gyros on antenna; Two-axis az-el; Monopulse; Complementary filters; Freeze during blockage; Basic built-in); the choice is robust: in 66% of weight perturbations the leader is unchanged,
  and in 98% the core of the solution (monopulse + ACM freeze) is preserved. Novelty relative to the analogues n(V) = 2.

### 2. Consistency of models at two fidelity levels as a detector of false assumptions (RQ2)
* The shortlist ranks from LF and from the twin agree (Spearman ρ = 0.97), so the stage 3 choice is confirmed.
* The discrepancy for P1 (three-axis, step tracking) (> 2 p.p.) triggered **feedback 4→3**: the refined step-tracking model did not change the choice.
* The best prototype achieves Θ = **98.97 %** at a cost of 19.6 c.u.; P4 achieves 99.37 % at 27.6 c.u.
  (+41 %), while the phased-array variants reach only ≈ 84.2 % (violating TS.5): this is the quantified "price of a low profile".
* The throughput of good variants is determined by **blockage handling** (F6), not by pointing accuracy: pointing losses in V3 are fractions of a hundredth of a dB.

### 3. Digital verification and testing (RQ3)
* V&V: 7/7 tests; TS.3–TS.4 were met in 200/200 runs of each of scenarios B and C → lower bound on the probability of compliance
  $p_L$ = 0.985 (Clopper–Pearson, 95 %).
* Sobol indices (GP surrogate, R² ≥ 0.99) showed that accuracy is driven by **residual isolation, base motion amplitude, tracking bandwidth** —
  precisely the parameters that were calibrated first.
* Critical faults: el.-axis gyro failure (t=30 s), beacon receiver failure (t=40 s); BO found the worst-case motion (0.88 Hz, 9.8°) in 30 runs instead of 128 (×4.3).
* The nominal twin was "optimistic"; after hierarchical calibration the criterion $|E|\le2u_{val}$ on **independent data** is met
  (yes), the area metric decreased by 18 %, and validation credibility rose to level 3.
* Testing revealed **a phenomenon absent from the model** — a thermal boresight shift of ≈ 0.12°; feedback **6→4** was triggered, the twin was extended with a thermal correction,
  and compensation was introduced in the terminal (residual ≤ 0.010°). Stage 5 raises model credibility but not TRL: the prototype reached **TRL 5** only after testing.

### 4. Agentic system with bounded autonomy (RQ4)
* No claim was accepted without evidence: the critic rejected 10 of 71 claims in A1's first submission
  (paraphrased and fabricated quotes); in the final artefacts g = 1.000.
* LS1: RAG + critic gives F1 = 0.94 with 0 % unverified claims (without RAG — F1 = 0.86).
* LS6: the full system detected 100% of injected defects with 0 unauthorised actions;
  without the critic — 64%, without gates — 80% and 4 unauthorised irreversible actions.
  **The critic and the gates complement each other** — ablating either of them breaks target H6.
* Agent S blocked the instruction injection in a document and the external transfer of a confidential document; changing the TS, selecting the prototype, operating the bench outside
  the safe range and filing the application were always performed only by human decision.
