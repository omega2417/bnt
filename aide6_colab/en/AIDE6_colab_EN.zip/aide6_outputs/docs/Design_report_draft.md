# Design report: best prototype bbacaba

> **DRAFT** by agent D (AIDE-6), 2026-11-05T00:08:14+00:00. Requires editing and approval by a human.


## Narrowing of the solution space
4608 → 1476 compatible → 810 feasible → 42 on the Pareto front → 8 twins → 1 prototype.

## Best prototype V3 = bbacaba
F1: Single-antenna GNSS/INS; F2: MEMS gyros on antenna; F3: Two-axis az-el; F4: Monopulse; F5: Complementary filters; F6: Freeze during blockage; F7: Basic built-in.
Cost 19.6 c.u., risk r = 2, Θ (twin) = 98.97 %.

## Compliance with the TS (tests)
| requirement | verification | result | conclusion | protocol |
|---|---|---|---|---|
| TS.3 | T4, T6 | ε95 = 0.042° in scenario C; worst RMS in T6 ≈ 0.062° | met | PR-T4-002 |
| TS.4 | T4 | εmax = 0.060°, ε99 = 0.183° outside blockages | met | PR-T4b-003 |
| TS.5 | T4 + channel emulator | Θ = 98.86 % including unavailability | met | PR-T4c-004 |
| TS.6 | T3 | no reacquisition needed (|ε| at the end ≤ 0.437°); outage 0.022 s (std. ACM: 1.07–1.13 s) | met | PR-T3-005 |
| TS.7 | T5, T6 | shift 0.117° without compensation; with compensation ≤ 0.010° over −20…+40 °C | partially; full range in the next series | PR-T5-006 |
| TS.14 | simulation | not tested on the bench; twin: 5/5 runs | simulation only | PR-SIM-GNSS-007 |


TRL = 5. Twin: version 3 (calibrated (hierarchically) + thermal correction).
