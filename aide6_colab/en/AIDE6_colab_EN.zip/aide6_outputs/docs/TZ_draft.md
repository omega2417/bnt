# Technical specification for a Ka-band antenna terminal

> **DRAFT** by agent D (AIDE-6), 2026-11-05T00:08:14+00:00. Requires editing and approval by a human.

| ID | Requirement | Limit | Verification method |
|---|---|---|---|
| TS.3 | Pointing error ε95 on straight segments | <= 0.1 ° | simulation + T4, T6 |
| TS.4 | Maximum error εmax during manoeuvres (outside blockages) | <= 0.2 ° | simulation + T4 |
| TS.5 | Weighted relative throughput Θ | >= 95.0 % | simulation + T4 with channel emulator |
| TS.6 | Blockages up to 10 s without reacquisition, recovery ≤ 1 s | <= 1.0 s | T3 |
| TS.7 | Operating temperature −40…+55 °C (axis shift ≤ 0.05°) | <= 0.05 ° | T5, T6 |
| TS.14 | GNSS outage up to 60 s without violating TS.4 | <= 0.2 ° | simulation |
