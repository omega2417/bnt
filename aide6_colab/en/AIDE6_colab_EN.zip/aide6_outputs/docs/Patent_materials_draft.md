# Utility model application materials (draft)

> **DRAFT** by agent D (AIDE-6), 2026-11-05T00:08:14+00:00. Requires editing and approval by a human.


**Closest analogue:** class P2 (bbabaaa): UA-SYN-0203-U, UA-SYN-0204-U.

**Distinguishing features (n(V) = 2):** F4 — Monopulse instead of “Conical scan”; F6 — Freeze during blockage instead of “Standard ACM”.

**Technical result:** throughput loss reduced from 2.40 to 1.03 p.p. (twin).

> The Hamming novelty metric does not replace a patent search over the full prior art. Filing is by human decision only.
