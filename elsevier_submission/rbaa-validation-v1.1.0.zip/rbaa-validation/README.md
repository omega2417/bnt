# rbaa-validation: back-test of risk-based attention allocation on real open data (v1.1.0)

Validation companion to the article **"Cognitive optimisation of AI-supported SME decisions through risk-based
allocation of managerial attention"** (Torstensson, Prokopovych-Tkachenko, Britchenko, Ilessova, Chubaievskyi &
Merkibaeva; manuscript submitted to *Digital Business*, Elsevier). It reproduces **Appendix B** (archived back-test) and
**Figures B1–B3**. It complements the model-reproduction package `rbaa-sim`; the extended comparison with seven
allocation rules in Section 5 is reproduced by `rbaa-benchmark` (Supplementary Material S1).

## Run it
**Google Colab:** *File → Upload notebook* → `RBAA_validation_colab.ipynb` → *Runtime → Run all*. A run takes about
1–3 minutes, including the download of the data (≈150 MB). The last cell downloads all outputs as a zip.
**Local:** `pip install -r requirements.txt jupyter`, then
`jupyter nbconvert --to notebook --execute RBAA_validation_colab.ipynb`.

## What is validated, and what is not
No open statistical source records whether enterprises use RBAA or what it earns them, and this package does not invent
such records. It uses the real data that do exist:

* **Part A, context (Eurostat).** The share of EU enterprises using at least one AI technology by size class, 2023–2025,
  as printed in Eurostat (2026b), Figure 1 (2025: small 17.0 %, medium 30.4 %, large 55.0 %, all 20.0 %). These values
  describe adoption only; they say nothing about verification practices or the effectiveness of RBAA.
* **Part B, back-test (284,807 real transactions with fraud labels).** An AI model is trained on the first 60 % of elapsed
  time. On the remaining 129,878 operations, the RBAA routing rule is compared with amount-based approval limits, random
  spot checks and an AI-score alert queue under the same budget of managerial attention, in euros. Reviewer behaviour is
  an assumption, varied in a sensitivity analysis: detection q(L), harmful override h(L) and cost per review κ = €5
  (10 minutes at €30/h). Amounts and outcome labels are real.

## Main results (archived run, default assumptions) — as printed in Appendix B

| Indicator | Value |
|---|---|
| Net benefit at 129 reviews (0.10 % of operations, 21.5 h): RBAA / AI-score queue / random checks / amount-based ranking | €10,351.82 / €8,878.00 / −€694.68 / −€3,942.76 |
| RBAA − AI-score queue (same attention) | €1,473.82, 95 % bootstrap interval −€417.45 to €3,513.84; one-sided tail proportion 0.0769 |
| RBAA − random checks; RBAA − amount-based ranking | intervals above zero; tail proportions 0.001 |
| Load-aware vs isolated (marginal-only) stopping rule | €10,351.82 vs €9,572.97 |
| RBAA with a €1,000 hard floor | 1,474 reviews (245.67 h), −€24,419.09; modelled price of the floor €34,770.91 |
| Mean predicted fraud probability vs observed rate | 0.00172 vs 0.00110 |

The notebook checks all 14 values (`outputs/tableB7_appendixB_reproduction.csv`). Every claim tested in the notebook is
listed in `outputs/findings.csv`, including those that are **not supported** (e.g. the advantage over the AI-score queue
is not distinguishable from zero, and an AI-score queue tuned with hindsight earns slightly more than ex-ante RBAA).
The bootstrap tail proportions describe the resampling procedure and are not randomised-trial *p*-values.

| Output file | Article element |
|---|---|
| `outputs/figA_eurostat_ai_adoption.png/.pdf`, `tableA_eurostat_ai_adoption.csv` | Figure B1 |
| `outputs/figB2_net_benefit_curves.png/.pdf` | Figure B2 |
| `outputs/figB3_kpis_same_budget.png/.pdf`, `tableB3_economic_kpis.csv` | Figure B3, Appendix B |
| `outputs/tableB2_ai_quality.csv`, `tableB4_bootstrap.csv`, `tableB5_sensitivity.csv`, `tableB6_robustness.csv` | Appendix B |
| `outputs/tableB7_appendixB_reproduction.csv` | reproduction check of Appendix B |

## Changes from v1.0.0
* Article title and journal updated (*Digital Business*, Elsevier).
* Part A uses the values printed in Eurostat (2026b), Figure 1, which Figure B1 of the article redraws (v1.0.0 used a
  snapshot partly derived from news releases); the live `isoc_eb_ai` table is compared when reachable. The size-class
  framing is neutral (no claims about large enterprises).
* The bootstrap quantity is labelled a one-sided tail proportion; "CI" is labelled a bootstrap interval.
* New reproduction check of all values printed in Appendix B; English-only report.
* Part B computations are unchanged; with scikit-learn 1.9.1 all archived values are reproduced to the cent.

## Limits
1. The domain is card payments of one European processor in 2013, not invoice approval in SMEs.
2. Reviewer behaviour (q, h, κ) is assumed, so euro values are conditional on the configuration.
3. This is a counterfactual back-test over fewer than two days, not a randomised experiment. It does not show that any
   firm uses RBAA. The field experiment proposed in Appendix C of the article is still needed to test H1–H5.

## Archive contents
```
RBAA_validation_colab.ipynb   executed notebook (explanations, code, tables, figures)
REPORT.html                   self-contained report: tables + figures + sources (open in any browser)
outputs/                      tables (CSV), figures (PNG 300 dpi + PDF), findings.csv, config.json,
                              environment.json, test_report.csv, MANIFEST.sha256
DATA_SOURCES.md               data provenance, licences, checksums, citations
requirements.txt, CITATION.cff, .zenodo.json, LICENSE (MIT, code only)
```
