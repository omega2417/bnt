# Data sources and licences

The archive contains **no raw third-party data**. The notebook downloads the transaction data at run time and verifies
the file.

| Data | Provider | Access in the notebook | Licence / terms | Use |
|---|---|---|---|---|
| Credit Card Fraud Detection: 284,807 card transactions by European cardholders, September 2013; 492 labelled frauds; `Amount` in EUR; PCA features V1–V28 | Worldline and the Machine Learning Group of Université Libre de Bruxelles (ULB) | `https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv` (TensorFlow mirror), SHA-256 `76274b691b16a6c49d3f159c883398e03ccd6d1ee12d9d8ee38f4b4b98551a89` | Open Database License (ODbL) v1.0 / Database Contents License, as distributed by the ULB MLG on Kaggle | Real decision stream for the back-test (Part B) |
| Use of AI technologies by enterprise size class, 2023–2025 (% of enterprises with 10+ persons employed) | Eurostat | Values printed in Eurostat (2026b), Figure 1, p. 14 (default); the live dissemination API table `isoc_eb_ai` (indicator `E_AI_TANY`, unit `PC_ENT`, EU27_2020) is compared when reachable | Eurostat re-use policy (CC BY 4.0) | Context (Part A), Figure B1 |

If the TensorFlow mirror becomes unavailable, download `creditcard.csv` from the ULB MLG Kaggle page
(https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud) and place it in `data/creditcard.csv` next to the notebook.
The checksum check confirms that the file is identical. The data licence is distinct from the MIT licence of the code;
the code licence does not relicense the data.

**Citations**
- Machine Learning Group, Université Libre de Bruxelles. (n.d.). *Credit card fraud detection* [Data set]. Kaggle.
  https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
- Dal Pozzolo, A., Caelen, O., Johnson, R. A., & Bontempi, G. (2015). Calibrating probability with undersampling for
  unbalanced classification. In *2015 IEEE Symposium Series on Computational Intelligence* (pp. 159–166). IEEE.
  https://doi.org/10.1109/SSCI.2015.33
- Eurostat. (2026a). *Artificial intelligence by size class of enterprise* (isoc_eb_ai) [Data set].
  https://ec.europa.eu/eurostat/databrowser/view/isoc_eb_ai/default/table
- Eurostat. (2026b). *The use of artificial intelligence technologies in the European Union: Key results — 2026
  edition*. Publications Office of the European Union. https://doi.org/10.2785/9221093
