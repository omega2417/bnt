"""Assemble Tables 3 and 4 of the article, the Appendix B reconciliation and a check of every number quoted in
Section 5 against the result files written by run_all.py.

Usage: python paper_tables.py data out
Writes out/table3_validation.csv, out/table4_economics.csv, out/appendixB_reconciliation.csv,
out/paper_values_check.csv, out/environment.json and out/MANIFEST.sha256. Exits with status 1 if any check fails.
"""
import hashlib, json, platform, sys
from pathlib import Path
import numpy as np, pandas as pd

D, O = Path(sys.argv[1]), Path(sys.argv[2])
R = json.load(open(O / 'summary.json'))
N, FV = R['N'], R['fraud_value']
T = {k: pd.read_csv(O / f'table_{k}.csv').set_index('method') for k in ('tight', 'generous', 'matched')}
RB = 'RBAA (load-aware)'
ORDER = ['Random audit', 'Amount-based approval limit', 'Classifier threshold (p≥0.5)', 'AI-score alert queue',
         'Cost-sensitive EL ranking', 'Fixed-accuracy deferral', 'Isolated value-of-review rule', RB]
LABEL = {'Random audit': 'Random audit (spot checks)', 'Amount-based approval limit': 'Amount-based approval limits',
         'Classifier threshold (p≥0.5)': 'Classifier threshold (p ≥ 0.5)', 'AI-score alert queue': 'AI-score alert queue',
         'Cost-sensitive EL ranking': 'Cost-sensitive expected-loss ranking',
         'Fixed-accuracy deferral': 'Fixed-accuracy deferral (learning-to-defer logic)',
         'Isolated value-of-review rule': 'Isolated value-of-review rule', RB: 'RBAA (load-aware stopping)'}
bs = R['bootstrap']

# ---- Table 3
rows = []
for m in ORDER:
    g = T['generous'].loc[m]
    adv = '—' if m == RB else '{:.1f} [{:.1f}, {:.1f}]'.format(bs['generous'][m]['mean'], bs['generous'][m]['lo'], bs['generous'][m]['hi'])
    rows.append({'Allocation rule': LABEL[m], 'Reviews': int(g.reviews), 'Review hours': round(g.hours, 1),
                 'Net benefit, tight budget': round(T['tight'].loc[m].nb_per_1000, 1),
                 'Net benefit, generous budget': round(g.nb_per_1000, 1),
                 'RBAA advantage [95% CI]': adv, 'Net € per review hour': int(round(g.net_per_hour))})
t3 = pd.DataFrame(rows); t3.to_csv(O / 'table3_validation.csv', index=False)

# ---- Table 4
ECO = [RB, 'AI-score alert queue', 'Cost-sensitive EL ranking', 'Amount-based approval limit']
t4 = pd.DataFrame({LABEL[m]: {
    'Reviews (review hours)': f"{int(T['generous'].loc[m].reviews)} ({T['generous'].loc[m].hours:.1f})",
    'Fraud value corrected, % of value at risk': round(100 * T['generous'].loc[m].caught_share, 1),
    'Harmful-override loss, € per 1,000 operations': round(T['generous'].loc[m].harm / N * 1000, 2),
    'Review cost, € per 1,000 operations': round(T['generous'].loc[m].review_cost / N * 1000, 2),
    'Total cost of control (TCC), € per 1,000 operations': round(T['generous'].loc[m].tcc_per_1000, 2),
    'Reduction in TCC relative to unreviewed execution, %': round(100 * T['generous'].loc[m].tcc_reduction, 1),
    'Net economic effect per review hour, €': int(round(T['generous'].loc[m].net_per_hour)),
    'Net return per € of review cost': round(T['generous'].loc[m].roi, 1)} for m in ECO})
t4.index.name = 'Indicator'; t4.to_csv(O / 'table4_economics.csv')

# ---- Appendix B reconciliation (archived rbaa-validation v1.0.0 vs this re-run)
fl = pd.read_csv(O / 'hard_floor.csv')
f1000 = fl[(fl.M == 1000) & (~fl.deputy) & (fl.omega == 1.0)].iloc[0]
rec = pd.DataFrame([
    ('RBAA, 129 reviews', 10351.82, T['tight'].loc[RB].nb),
    ('AI-score queue, 129 reviews', 8878.00, T['tight'].loc['AI-score alert queue'].nb),
    ('Random checks, 129 reviews', -694.68, T['tight'].loc['Random audit'].nb),
    ('Amount-based ranking, 129 reviews', -3942.76, T['tight'].loc['Amount-based approval limit'].nb),
    ('RBAA with EUR 1,000 hard floor', -24419.09, f1000.nb),
    ('Reviews with EUR 1,000 hard floor', 1474, f1000.reviews),
], columns=['quantity', 'archived_v1.0.0', 're_run'])
rec.to_csv(O / 'appendixB_reconciliation.csv', index=False)

# ---- every number quoted in Section 5, Tables 3-4 and Appendix B (re-run paragraph) of the article
cm = pd.read_csv(D / 'classifier_metrics.csv').set_index('model').loc['HGB seed 0']
cal = pd.read_csv(O / 'calibration.csv'); clf = pd.read_csv(O / 'classifiers.csv'); te = pd.read_csv(D / 'test_scored.csv')
mid = cal[cal.gamma.between(0.75, 1.5)]
gen = clf[clf.regime == 'generous']; tig = clf[clf.regime == 'tight']
others = [m for m in ORDER if m != RB]
sens = R['sensitivity']
def pt(reg, m): return T[reg].loc[RB].nb_per_1000 - T[reg].loc[m].nb_per_1000
P = [  # (quantity, value in the article, value computed here, tolerance)
    ('test transactions', 129878, N, 0), ('test frauds', 143, R['frauds'], 0), ('fraud value EUR', 21159.67, FV, 0.005),
    ('test period hours', 19.2, R['hours'], 0.05), ('10-minute blocks', 116, len(np.unique(te.Time // 600)), 0),
    ('ROC AUC', 0.948, cm.auc, 0.0005), ('average precision', 0.683, cm.ap, 0.0005), ('Brier', 0.00053, cm.brier, 0.000005),
    ('mean predicted p', 0.00159, cm.mean_p, 0.000005), ('observed fraud rate', 0.00110, te.Class.mean(), 0.000005),
    ('tight budget', 129, R['B1'], 0), ('generous budget', 649, R['B2'], 0), ('RBAA reviews, generous', 162, R['k_rbaa_generous'], 0),
    ('RBAA net per 1,000, generous', 79.3, T['generous'].loc[RB].nb_per_1000, 0.05),
    ('AI-score net per 1,000, generous', 48.3, T['generous'].loc['AI-score alert queue'].nb_per_1000, 0.05),
    ('EL net per 1,000, generous', 14.6, T['generous'].loc['Cost-sensitive EL ranking'].nb_per_1000, 0.05),
    ('amount limits net per 1,000, generous', -97.2, T['generous'].loc['Amount-based approval limit'].nb_per_1000, 0.05),
    ('random audit net per 1,000, generous', -28.1, T['generous'].loc['Random audit'].nb_per_1000, 0.05),
    ('RBAA - AI score, point, generous', 31.0, pt('generous', 'AI-score alert queue'), 0.05),
    ('RBAA - AI score, bootstrap mean', 30.9, bs['generous']['AI-score alert queue']['mean'], 0.05),
    ('RBAA - threshold, point', 19.1, pt('generous', 'Classifier threshold (p≥0.5)'), 0.05),
    ('RBAA - threshold, bootstrap mean', 18.3, bs['generous']['Classifier threshold (p≥0.5)']['mean'], 0.05),
    ('RBAA - isolated, point', 3.2, pt('generous', 'Isolated value-of-review rule'), 0.05),
    ('RBAA - fixed-accuracy, point', 5.2, pt('generous', 'Fixed-accuracy deferral'), 0.05),
    ('matched: value-of-review vs AI-score ranking', 9.8, pt('matched', 'AI-score alert queue'), 0.05),
    ('matched: bootstrap mean vs AI score', 7.6, bs['matched']['AI-score alert queue']['mean'], 0.05),
    ('matched: vs EL ranking', 1.8, pt('matched', 'Cost-sensitive EL ranking'), 0.05),
    ('matched: bootstrap mean vs EL', 2.2, bs['matched']['Cost-sensitive EL ranking']['mean'], 0.05),
    ('gain from stopping vs AI score', 21.2, T['matched'].loc['AI-score alert queue'].nb_per_1000 - T['generous'].loc['AI-score alert queue'].nb_per_1000, 0.05),
    ('tight: RBAA - AI score, point', 16.0, pt('tight', 'AI-score alert queue'), 0.05),
    ('tight: bootstrap mean vs AI score', 14.1, bs['tight']['AI-score alert queue']['mean'], 0.05),
    ('tight: RBAA - EL, point', 1.9, pt('tight', 'Cost-sensitive EL ranking'), 0.05),
    ('sensitivity: share best or tied, generous', 0.957, sens['gen']['share_rbaa_best_or_tied'], 0.0005),
    ('sensitivity: share best or tied, matched', 0.938, sens['mat']['share_rbaa_best_or_tied'], 0.0005),
    ('sensitivity: share best or tied, tight', 0.799, sens['tig']['share_rbaa_best_or_tied'], 0.0005),
    ('sensitivity: median gain vs best, generous', 2.6, sens['gen']['median_diff_vs_best'], 0.05),
    ('sensitivity: largest shortfall, generous', -2.5, sens['gen']['min_diff'], 0.05),
    ('sensitivity: never below AI score / EL, generous', 1.0, min(sens['gen']['share_vs_AIscore_pos'], sens['gen']['share_vs_EL_pos']), 0),
    ('classifiers: RBAA best in all six, generous', 1.0, float((gen[RB] >= gen[others].max(axis=1) - 1e-9).all()), 0),
    ('classifiers: min RBAA, generous', 57.6, gen[RB].min(), 0.05), ('classifiers: max RBAA, generous', 79.3, gen[RB].max(), 0.05),
    ('classifiers: AI score better in tight', 2, int((tig['AI-score alert queue'] > tig[RB]).sum()), 0),
    ('calibration: RBAA > AI score in twelve settings', 1.0, float((mid[RB] > mid['AI-score alert queue']).all()), 0),
    ('calibration: min RBAA (slope 0.75-1.5)', 55.3, mid[RB].min(), 0.05), ('calibration: max RBAA (slope 0.75-1.5)', 81.1, mid[RB].max(), 0.05),
    ('calibration: slope 0.5, shift 0', 10.8, cal[(cal.gamma == 0.5) & (cal.delta == 0)][RB].iloc[0], 0.05),
    ('calibration: slope 0.5, shift +1', -18.3, cal[(cal.gamma == 0.5) & (cal.delta == 1)][RB].iloc[0], 0.05),
    ('TCC unreviewed per 1,000', 162.92, FV / N * 1000, 0.005),
    ('TCC RBAA per 1,000', 83.62, T['generous'].loc[RB].tcc_per_1000, 0.005),
    ('TCC reduction RBAA %', 48.7, 100 * T['generous'].loc[RB].tcc_reduction, 0.05),
    ('TCC reduction AI score %', 29.6, 100 * T['generous'].loc['AI-score alert queue'].tcc_reduction, 0.05),
    ('TCC reduction EL %', 8.9, 100 * T['generous'].loc['Cost-sensitive EL ranking'].tcc_reduction, 0.05),
    ('TCC change amount limits %', -59.7, 100 * T['generous'].loc['Amount-based approval limit'].tcc_reduction, 0.05),
    ('net per review hour RBAA', 381, T['generous'].loc[RB].net_per_hour, 0.5),
    ('net per review hour AI score', 58, T['generous'].loc['AI-score alert queue'].net_per_hour, 0.5),
    ('return per EUR of review RBAA', 12.7, T['generous'].loc[RB].roi, 0.05),
    ('TCC gap AI score vs RBAA, % of value at risk', 19.0, 100 * (T['generous'].loc['AI-score alert queue'].tcc - T['generous'].loc[RB].tcc) / FV, 0.05),
    ('review hours released', 81, T['generous'].loc['AI-score alert queue'].hours - T['generous'].loc[RB].hours, 0.5),
    ('shadow price EUR per minute, tight', 1.66, R['shadow_price_per_min_at_129'], 0.005),
    ('shadow price EUR per minute, generous', 0.0, R['shadow_price_per_min_at_649'], 1e-9),
    ('floor 1,000: mandatory reviews', 1414, f1000.k_mand, 0), ('floor 1,000: net EUR', -24675.58, f1000.nb, 0.005),
    ('floor 1,000: net per 1,000', -190, f1000.nb_per_1000, 0.5), ('floor 1,000: price EUR', 34974, f1000.cost_of_floor, 0.5),
    ('floor 1,000: price per mandatory review', 24.7, f1000.cost_per_mandatory_review, 0.05),
    ('floor 1,000 with deputy: price', 31095, fl[(fl.M == 1000) & fl.deputy & (fl.omega == 1.0)].cost_of_floor.iloc[0], 0.5),
    ('floor 5,000: mandatory reviews', 26, fl[(fl.M == 5000) & ~fl.deputy & (fl.omega == 1.0)].k_mand.iloc[0], 0),
    ('floor 5,000: price', 938, fl[(fl.M == 5000) & ~fl.deputy & (fl.omega == 1.0)].cost_of_floor.iloc[0], 0.5),
    ('floor 5,000: net per 1,000', 72.1, fl[(fl.M == 5000) & ~fl.deputy & (fl.omega == 1.0)].nb_per_1000.iloc[0], 0.05),
    ('floor 1,000, omega 0.25: price', 15146, fl[(fl.M == 1000) & ~fl.deputy & (fl.omega == 0.25)].cost_of_floor.iloc[0], 0.5),
    ('re-run RBAA 129 reviews EUR', 10111.82, T['tight'].loc[RB].nb, 0.005),
    ('re-run AI score 129 reviews EUR', 8028.48, T['tight'].loc['AI-score alert queue'].nb, 0.005),
    ('re-run random 129 reviews EUR', -715.96, T['tight'].loc['Random audit'].nb, 0.005),
    ('re-run amount 129 reviews EUR', -3942.76, T['tight'].loc['Amount-based approval limit'].nb, 0.005),
]
chk = pd.DataFrame(P, columns=['quantity', 'article', 'computed', 'tolerance'])
chk['passed'] = (chk.article - chk.computed).abs() <= chk.tolerance + 1e-9
chk.to_csv(O / 'paper_values_check.csv', index=False)
print(t3.to_string(index=False)); print(t4.to_string()); print(rec.to_string(index=False))
print(f"{chk.passed.sum()} / {len(chk)} values quoted in the article reproduced")
if not chk.passed.all():
    print(chk[~chk.passed].to_string(index=False))

import sklearn, scipy, matplotlib
env = {'python': sys.version.split()[0], 'platform': platform.platform(), 'numpy': np.__version__, 'pandas': pd.__version__,
       'scikit-learn': sklearn.__version__, 'scipy': scipy.__version__, 'matplotlib': matplotlib.__version__,
       'data_sha256': hashlib.sha256((D / 'creditcard.csv').read_bytes()).hexdigest(), 'rbaa_benchmark_version': '1.0.0'}
(O / 'environment.json').write_text(json.dumps(env, indent=2))
man = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(O.iterdir()) if p.is_file() and p.name != 'MANIFEST.sha256'}
(O / 'MANIFEST.sha256').write_text(''.join(f'{h}  {n}\n' for n, h in man.items()))
sys.exit(0 if chk.passed.all() else 1)
