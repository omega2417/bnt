#!/usr/bin/env bash
# Reproduce Section 5, Tables 3-4, Figures 2-3 and the Appendix B reconciliation of the article.
set -euo pipefail
cd "$(dirname "$0")"
python get_data.py data
python prep.py data
PYTHONPATH=. python run_all.py data outputs
python figs.py outputs
python paper_tables.py data outputs
