"""Section 5 of the article: regimes, paired block bootstrap, budget sweep, 324-scenario sensitivity, calibration
distortion, classifier robustness and the price of the hard floor.

Usage: PYTHONPATH=. python run_all.py data out   (about 4-5 minutes)
"""
import numpy as np, pandas as pd, json, sys, itertools, time
from rbaa_validate import *

D = sys.argv[1]; OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
te = pd.read_csv(f'{D}/test_scored.csv')
A = te.Amount.values; y = te.Class.values; t = te.Time.values; p = te.p.values; N = len(te)
P = dict(BASE)
FV = float((A * y).sum())
R = {'N': N, 'frauds': int(y.sum()), 'fraud_value': FV, 'hours': (t.max() - t.min()) / 3600}
B1 = 129; B2 = int(round(0.005 * N))
R['B1'] = B1; R['B2'] = B2


def table(res):
    rows = []
    for m, v in res.items():
        hrs = v['k'] * P['minutes'] / 60
        tcc = FV - v['caught'] + v['harm'] + v['cost']
        rows.append(dict(method=m, reviews=v['k'], hours=hrs, nb=v['nb'], nb_per_1000=v['nb'] / N * 1000,
                         caught_share=v['caught'] / FV, harm=v['harm'], review_cost=v['cost'],
                         net_per_hour=v['nb'] / hrs if hrs else np.nan,
                         roi=v['nb'] / v['cost'] if v['cost'] else np.nan,
                         tcc=tcc, tcc_per_1000=tcc / N * 1000, tcc_reduction=1 - tcc / FV))
    return pd.DataFrame(rows)


rng = np.random.default_rng(1)
r1 = evaluate(A, p, y, P, B1, rng)
r2 = evaluate(A, p, y, P, B2, np.random.default_rng(1))
kR = r2['RBAA (load-aware)']['k']
r3 = evaluate(A, p, y, P, B2, np.random.default_rng(1), matched=kR)
for name, r in [('tight', r1), ('generous', r2), ('matched', r3)]:
    table(r).to_csv(f'{OUT}/table_{name}.csv', index=False)
R['k_rbaa_generous'] = kR

# bootstrap (10-minute blocks)
t0 = time.time()
bs = {}
for name, B, mt in [('tight', B1, False), ('generous', B2, False), ('matched', B2, True)]:
    df = bootstrap(A, p, y, t, P, B, reps=1000, width=600, matched_from_rbaa=mt)
    df.to_csv(f'{OUT}/boot_{name}.csv', index=False)
    s = {}
    for m in METHODS:
        if m == 'RBAA (load-aware)':
            continue
        d = df['RBAA (load-aware)'] - df[m]
        s[m] = dict(mean=float(d.mean()), lo=float(d.quantile(.025)), hi=float(d.quantile(.975)),
                    p_le0=float((d <= 0).mean()))
    bs[name] = s
# hour blocks for comparison with archive
df = bootstrap(A, p, y, t, P, B1, reps=1000, width=3600)
d = df['RBAA (load-aware)'] - df['AI-score alert queue']
bs['tight_hourblocks_vs_AIscore'] = dict(mean=float(d.mean()), lo=float(d.quantile(.025)), hi=float(d.quantile(.975)), p_le0=float((d <= 0).mean()))
R['bootstrap'] = bs
R['boot_seconds'] = time.time() - t0

# budget sweep
grid = sorted(set([25, 50, 75, 100, 129, 162, 200, 250, 300, 400, 500, 649, 800, 1000, 1300, 1600, 2000, 2600]))
sw = []
for B in grid:
    r = evaluate(A, p, y, P, B, np.random.default_rng(1))
    for m, v in r.items():
        sw.append(dict(budget=B, method=m, reviews=v['k'], nb_per_1000=v['nb'] / N * 1000))
pd.DataFrame(sw).to_csv(f'{OUT}/budget_sweep.csv', index=False)

# shadow price of attention for RBAA at tight budget (EUR per review minute)
def nbB(B):
    return evaluate(A, p, y, P, B, np.random.default_rng(1))['RBAA (load-aware)']['nb']
R['shadow_price_per_min_at_129'] = (nbB(139) - nbB(119)) / (20 * P['minutes'])
R['shadow_price_per_min_at_649'] = (nbB(659) - nbB(639)) / (20 * P['minutes'])

# sensitivity grid
sens = []
for q0, qs, hs, cap, kap, om in itertools.product([0.7, 0.9], [0.25, 0.5, 1.0], [0.005, 0.01, 0.02],
                                                  [0.01, 0.02, 0.05], [2.5, 5.0, 10.0], [1.0, 0.25]):
    Q = dict(BASE, q0=q0, qs=qs, hs=hs, cap=cap, kappa=kap, omega=om)
    g = evaluate(A, p, y, Q, B2, np.random.default_rng(1))
    kq = g['RBAA (load-aware)']['k']
    mm = evaluate(A, p, y, Q, B2, np.random.default_rng(1), matched=kq)
    tt = evaluate(A, p, y, Q, B1, np.random.default_rng(1))
    row = dict(q0=q0, qs=qs, hs=hs, cap=cap, kappa=kap, omega=om, k_rbaa=kq)
    for tag, rr in [('gen', g), ('mat', mm), ('tig', tt)]:
        for m in METHODS:
            row[f'{tag}|{m}'] = rr[m]['nb'] / N * 1000
    sens.append(row)
S = pd.DataFrame(sens); S.to_csv(f'{OUT}/sensitivity.csv', index=False)
summ = {}
for tag in ['gen', 'mat', 'tig']:
    others = [f'{tag}|{m}' for m in METHODS if m != 'RBAA (load-aware)']
    best = S[others].max(axis=1); rb = S[f'{tag}|RBAA (load-aware)']
    diff = rb - best
    summ[tag] = dict(n=len(S), share_rbaa_best_or_tied=float((diff >= -1e-9).mean()),
                     median_diff_vs_best=float(diff.median()), min_diff=float(diff.min()),
                     share_vs_AIscore_pos=float((rb - S[f'{tag}|AI-score alert queue'] >= -1e-9).mean()),
                     median_diff_vs_AIscore=float((rb - S[f'{tag}|AI-score alert queue']).median()),
                     share_vs_EL_pos=float((rb - S[f'{tag}|Cost-sensitive EL ranking'] >= -1e-9).mean()),
                     median_diff_vs_EL=float((rb - S[f'{tag}|Cost-sensitive EL ranking']).median()),
                     share_vs_isolated_pos=float((rb - S[f'{tag}|Isolated value-of-review rule'] >= -1e-9).mean()),
                     median_diff_vs_isolated=float((rb - S[f'{tag}|Isolated value-of-review rule']).median()))
R['sensitivity'] = summ

# calibration distortion and alternative classifiers
def logit(x):
    x = np.clip(x, 1e-9, 1 - 1e-9); return np.log(x / (1 - x))
cal = []
for g_, d_ in itertools.product([0.5, 0.75, 1.0, 1.25, 1.5], [-1.0, 0.0, 1.0]):
    pp = 1 / (1 + np.exp(-(g_ * logit(p) + d_)))
    r = evaluate(A, pp, y, P, B2, np.random.default_rng(1))
    cal.append(dict(gamma=g_, delta=d_, **{m: r[m]['nb'] / N * 1000 for m in METHODS}, k_rbaa=r['RBAA (load-aware)']['k']))
pd.DataFrame(cal).to_csv(f'{OUT}/calibration.csv', index=False)
clf = []
for col in ['p', 'p_s1', 'p_s2', 'p_s3', 'p_s4', 'p_lr']:
    for B, tag in [(B1, 'tight'), (B2, 'generous')]:
        r = evaluate(A, te[col].values, y, P, B, np.random.default_rng(1))
        clf.append(dict(model=col, regime=tag, **{m: r[m]['nb'] / N * 1000 for m in METHODS}))
pd.DataFrame(clf).to_csv(f'{OUT}/classifiers.csv', index=False)

# hard floor
fl = []
for M, dep, om in itertools.product([1000, 2000, 3000, 5000, 10000], [False, True], [1.0, 0.25]):
    Q = dict(BASE, omega=om)
    r = floor_rbaa(A, p, y, Q, M, None, dep)
    base = evaluate(A, p, y, Q, N, np.random.default_rng(1))['RBAA (load-aware)']
    fl.append(dict(M=M, deputy=dep, omega=om, k_mand=r['k_mand'], reviews=r['k'], nb=r['nb'],
                   nb_per_1000=r['nb'] / N * 1000, nb_no_floor=base['nb'], cost_of_floor=base['nb'] - r['nb'],
                   cost_per_mandatory_review=(base['nb'] - r['nb']) / max(r['k_mand'], 1)))
pd.DataFrame(fl).to_csv(f'{OUT}/hard_floor.csv', index=False)

import shutil
shutil.copy(f'{D}/classifier_metrics.csv', f'{OUT}/classifier_metrics.csv')
json.dump(R, open(f'{OUT}/summary.json', 'w'), indent=1, default=float)
print(json.dumps(R, indent=1, default=float))
