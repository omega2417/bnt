"""Download the ULB/Worldline card-transaction data and verify its SHA-256.

Usage: python get_data.py [data_dir]          (default: ./data)
The file is not redistributed with this package (Open Database License, see DATA_SOURCES.md).
"""
import hashlib
import sys
import urllib.request
from pathlib import Path

URL = "https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv"
SHA256 = "76274b691b16a6c49d3f159c883398e03ccd6d1ee12d9d8ee38f4b4b98551a89"

D = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
D.mkdir(parents=True, exist_ok=True)
f = D / "creditcard.csv"
if not f.exists():
    print("Downloading", URL)
    urllib.request.urlretrieve(URL, f)
h = hashlib.sha256(f.read_bytes()).hexdigest()
if h != SHA256:
    sys.exit(f"SHA-256 mismatch for {f}: {h} (expected {SHA256}). "
             "If the mirror is unavailable, download creditcard.csv from the ULB MLG Kaggle page (see DATA_SOURCES.md).")
print(f"OK {f} SHA-256 {h}")
