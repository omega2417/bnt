"""Score the out-of-time test period with calibrated classifiers.

Usage: python prep.py data
Split at 60% of elapsed transaction time (as in rbaa-validation). Five histogram gradient-boosting seeds and a
logistic regression, each with isotonic calibration (three-fold cross-validation), are fitted on the earlier period;
the test period is used only for scoring. Writes data/test_scored.csv and data/classifier_metrics.csv.
"""
import hashlib, sys
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

SHA256 = "76274b691b16a6c49d3f159c883398e03ccd6d1ee12d9d8ee38f4b4b98551a89"
D = sys.argv[1]
h = hashlib.sha256(open(D + '/creditcard.csv', 'rb').read()).hexdigest()
assert h == SHA256, f"creditcard.csv SHA-256 {h} differs from {SHA256}; run get_data.py"
d = pd.read_csv(D + '/creditcard.csv')
cut = 0.6 * d.Time.max()
tr = d[d.Time <= cut]; te = d[d.Time > cut]
X = [c for c in d.columns if c not in ('Class', 'Time')]          # time stamp excluded from the features
out = te[['Time', 'Amount', 'Class']].copy()
rows = []
for seed in range(5):
    m = CalibratedClassifierCV(HistGradientBoostingClassifier(random_state=seed), method='isotonic', cv=3)
    m.fit(tr[X], tr.Class); p = m.predict_proba(te[X])[:, 1]
    out['p' if seed == 0 else f'p_s{seed}'] = p
    rows.append(('HGB seed %d' % seed, roc_auc_score(te.Class, p), average_precision_score(te.Class, p),
                 brier_score_loss(te.Class, p), p.mean()))
m = CalibratedClassifierCV(make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)), method='isotonic', cv=3)
m.fit(tr[X], tr.Class); p = m.predict_proba(te[X])[:, 1]; out['p_lr'] = p
rows.append(('Logistic', roc_auc_score(te.Class, p), average_precision_score(te.Class, p), brier_score_loss(te.Class, p), p.mean()))
out.to_csv(D + '/test_scored.csv', index=False)
r = pd.DataFrame(rows, columns=['model', 'auc', 'ap', 'brier', 'mean_p']); print(r.to_string()); r.to_csv(D + '/classifier_metrics.csv', index=False)
print('train', len(tr), 'test', len(te), 'test frauds', int(te.Class.sum()), 'fraud rate', te.Class.mean())
