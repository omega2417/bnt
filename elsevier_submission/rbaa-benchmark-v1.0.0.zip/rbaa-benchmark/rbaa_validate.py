"""RBAA validation against established review-allocation methods.

Data: ULB/Worldline card transactions, out-of-time test period (60% elapsed-time split).
Observed: amounts, fraud labels. Assumed: reviewer detection q(L), harmful override h(L),
review cost kappa, harmful-override loss fraction omega.  All money in EUR.
"""
import numpy as np, pandas as pd, json, sys, os

BASE = dict(q0=0.90, qs=0.50, h0=0.005, hs=0.010, cap=0.02, kappa=5.0, omega=1.0, minutes=10)

METHODS = ['Random audit', 'Amount-based approval limit', 'AI-score alert queue',
           'Cost-sensitive EL ranking', 'Classifier threshold (p≥0.5)',
           'Fixed-accuracy deferral', 'Isolated value-of-review rule', 'RBAA (load-aware)']


def qh(L, P):
    return np.clip(P['q0'] - P['qs'] * L, 0, 1), np.clip(P['h0'] + P['hs'] * L, 0, 1)


def realised(sel, A, y, N, P, extra=0):
    k = len(sel)
    if k == 0:
        return dict(k=0, nb=0.0, caught=0.0, harm=0.0, cost=0.0)
    q, h = qh((k + extra) / N / P['cap'], P)
    a, yy = A[sel], y[sel]
    caught = q * float((a * yy).sum()); harm = h * P['omega'] * float((a * (1 - yy)).sum())
    cost = P['kappa'] * k
    return dict(k=k, nb=caught - harm - cost, caught=caught, harm=harm, cost=cost)


def orders(A, p, P):
    q0, h0 = qh(0.0, P)
    v0 = q0 * p * A - h0 * (1 - p) * A * P['omega']
    return dict(v=np.argsort(-v0, kind='stable'), p=np.argsort(-p, kind='stable'),
                A=np.argsort(-A, kind='stable'), EL=np.argsort(-(p * A), kind='stable')), v0


def rbaa_stop(o, A, p, N, P, kmax, extra=0, base_gain=0.0, base_loss=0.0):
    o = o[:kmax]
    gain = base_gain + np.concatenate([[0], np.cumsum(p[o] * A[o])])
    loss = base_loss + np.concatenate([[0], np.cumsum((1 - p[o]) * A[o] * P['omega'])])
    k = np.arange(len(o) + 1)
    q, h = qh((k + extra) / N / P['cap'], P)
    return int(np.argmax(q * gain - h * loss - P['kappa'] * k))


def marginal_stop(o, A, p, N, P, kmax):
    o = o[:kmax]
    k = np.arange(1, len(o) + 1)
    q, h = qh(k / N / P['cap'], P)
    v = q * p[o] * A[o] - h * (1 - p[o]) * A[o] * P['omega']
    bad = np.where(v <= P['kappa'])[0]
    return int(bad[0]) if len(bad) else len(o)


def select(A, p, P, budget, rng, matched=None):
    """Selections of every method. budget: review cap (int). matched: if given, ranking
    methods without a stopping rule review exactly `matched` operations (<= budget)."""
    N = len(A); O, v0 = orders(A, p, P)
    kr = budget if matched is None else min(matched, budget)
    s = {}
    s['Random audit'] = rng.choice(N, size=kr, replace=False)
    s['Amount-based approval limit'] = O['A'][:kr]
    s['AI-score alert queue'] = O['p'][:kr]
    s['Cost-sensitive EL ranking'] = O['EL'][:kr]
    thr = O['p'][p[O['p']] >= 0.5]; s['Classifier threshold (p≥0.5)'] = thr[:budget]
    fa = O['v'][(v0[O['v']] - P['kappa']) > 0]; s['Fixed-accuracy deferral'] = fa[:budget]
    s['Isolated value-of-review rule'] = O['v'][:marginal_stop(O['v'], A, p, N, P, budget)]
    s['RBAA (load-aware)'] = O['v'][:rbaa_stop(O['v'], A, p, N, P, budget)]
    return s


def evaluate(A, p, y, P, budget, rng=None, matched=None):
    rng = rng or np.random.default_rng(1)
    N = len(A)
    return {m: realised(ix, A, y, N, P) for m, ix in select(A, p, P, budget, rng, matched).items()}


def floor_rbaa(A, p, y, P, M, budget=None, deputy=False):
    """RBAA with hard floor: amounts >= M are mandatory reviews; discretionary
    remainder by the load-aware rule. deputy: mandatory reviews go to a second reviewer."""
    N = len(A)
    mand = np.where(A >= M)[0]; rest = np.where(A < M)[0]
    q0, h0 = qh(0.0, P)
    v0 = q0 * p * A - h0 * (1 - p) * A * P['omega']
    o_full = rest[np.argsort(-v0[rest], kind='stable')]
    km = len(mand)
    kmax = len(o_full) if budget is None else max(0, budget - (0 if deputy else km))
    if deputy:
        kd = rbaa_stop(o_full, A, p, N, P, kmax)
        r1 = realised(o_full[:kd], A, y, N, P); r2 = realised(mand, A, y, N, P)
        r = {k: r1[k] + r2[k] for k in r1}
    else:
        bg = float((p[mand] * A[mand]).sum()); bl = float(((1 - p[mand]) * A[mand] * P['omega']).sum())
        kd = rbaa_stop(o_full, A, p, N, P, kmax, extra=km, base_gain=bg, base_loss=bl)
        r = realised(np.concatenate([mand, o_full[:kd]]), A, y, N, P)
    r['k_mand'] = km
    return r


def blocks(t, width):
    return (t // width).astype(int)


def bootstrap(A, p, y, t, P, budget, reps=1000, width=600, matched_from_rbaa=False, seed=7):
    """Paired bootstrap over non-overlapping time blocks (blocks drawn with replacement); the whole
    policy (ranking, stopping, budget share) is re-applied in each resample."""
    rng = np.random.default_rng(seed)
    b = blocks(t, width); ub = np.unique(b); idx = {u: np.where(b == u)[0] for u in ub}
    frac = budget / len(A)
    out = []
    for r in range(reps):
        pick = rng.choice(ub, size=len(ub), replace=True)
        ii = np.concatenate([idx[u] for u in pick])
        Ab, pb, yb = A[ii], p[ii], y[ii]
        B = max(1, int(round(frac * len(ii))))
        if matched_from_rbaa:
            O, _ = orders(Ab, pb, P)
            m = rbaa_stop(O['v'], Ab, pb, len(ii), P, B)
            res = evaluate(Ab, pb, yb, P, B, rng, matched=m)
        else:
            res = evaluate(Ab, pb, yb, P, B, rng)
        out.append({k: v['nb'] / len(ii) * 1000 for k, v in res.items()})
    return pd.DataFrame(out)
