# rbaa-benchmark — comparative validation of RBAA against seven allocation rules (v1.0.0)

Supplementary Material S1 of the article **"Cognitive optimisation of AI-supported SME decisions through risk-based
allocation of managerial attention"** (Torstensson, Prokopovych-Tkachenko, Britchenko, Ilessova, Chubaievskyi &
Merkibaeva; manuscript submitted to *Digital Business*, Elsevier).

It reproduces **Section 5** (Tables 3–4, Figures 2–3, robustness, economic indicators, price of the hard floor) and the
**re-run paragraph of Appendix B**. Companion packages: `rbaa-sim` (model, Appendix A, protocol code) and
`rbaa-validation` (archived back-test, Appendix B).

## Run it

```bash
python -m pip install -r requirements.txt
./run_all.sh            # download + verify data, score, evaluate, draw, check (about 5 minutes)
```
or step by step (data in `./data`, outputs in `./outputs`):

| Step | Command | What it does |
|---|---|---|
| 1 | `python get_data.py data` | downloads `creditcard.csv` and verifies SHA-256 `76274b69…51a89` |
| 2 | `python prep.py data` | 60 % elapsed-time split; calibrated histogram gradient boosting (5 seeds) and logistic regression; scores the test period |
| 3 | `PYTHONPATH=. python run_all.py data outputs` | three budget regimes, paired 10-minute block bootstrap (1,000 replications), budget sweep, 324-scenario sensitivity, calibration distortion, classifier robustness, hard-floor price |
| 4 | `python figs.py outputs` | Figures 2 and 3 |
| 5 | `python paper_tables.py data outputs` | Tables 3 and 4, Appendix B reconciliation, check of every number quoted in Section 5, environment and SHA-256 manifest |

**Google Colab:** upload `RBAA_benchmark_colab.ipynb`, run all cells and upload this archive's zip when prompted.

The exact values printed in the article were obtained with Python 3.13 and scikit-learn 1.9.1 (`outputs/environment.json`).
Step 5 compares 74 numbers quoted in the article with the values computed by the code
(`outputs/paper_values_check.csv`); all 74 pass in the archived run. Other scikit-learn versions refit slightly
different classifiers and can change the last digits.

## Design (Section 5.1 of the article)

* **Decision stream.** Out-of-time test period of the ULB/Worldline data: 129,878 transactions over 19.2 hours, 143
  labelled frauds, fraud value €21,159.67. Amounts and labels are observed.
* **AI recommendation.** Histogram gradient boosting with isotonic calibration (three-fold cross-validation), fitted on
  the first 60 % of elapsed time (ROC AUC 0.948, average precision 0.683, Brier score 0.00053).
* **Assumed reviewer behaviour** (`BASE` in `rbaa_validate.py`). Load L = e/0.02; detection q(L) = 0.90 − 0.50L; harmful
  override h(L) = 0.005 + 0.010L, clipped to [0, 1]; review cost κ = €5 for ten minutes; a harmful override costs the full
  amount (ω = 1).
* **Rules compared.** Random audit; amount-based approval limits; classifier threshold (p ≥ 0.5); AI-score alert queue;
  cost-sensitive expected-loss ranking (p·C); fixed-accuracy deferral (learning-to-defer logic with a load-independent
  expert); isolated value-of-review rule; RBAA (ranking by unloaded value of review, load-aware stopping that maximises
  predicted net performance, Eq. 3, using predicted probabilities only).
* **Regimes.** Tight budget of 129 reviews (0.1 %), generous budget of 649 reviews (0.5 %), and matched volume.
* **Uncertainty.** Paired bootstrap over 116 ten-minute blocks (1,000 replications), re-applying ranking, budget share
  and stopping in every resample.

## Output files and the article

| File | Article element |
|---|---|
| `outputs/table3_validation.csv` (from `table_tight/generous/matched.csv`, `boot_*.csv`) | Table 3 |
| `outputs/table4_economics.csv` | Table 4 |
| `outputs/fig2_budget_sweep.png` (from `budget_sweep.csv`) | Figure 2 |
| `outputs/fig3_economics.png` (from `hard_floor.csv`, `table_generous.csv`) | Figure 3 |
| `outputs/sensitivity.csv`, `calibration.csv`, `classifiers.csv`, `classifier_metrics.csv` | Section 5.3 |
| `outputs/summary.json` (shadow price, bootstrap summaries, sensitivity shares) | Sections 5.2–5.4 |
| `outputs/appendixB_reconciliation.csv` | Appendix B, re-run paragraph |
| `outputs/paper_values_check.csv` | all numbers quoted in Section 5 |

## Scope

Reviewer behaviour, costs and the harmful-override loss fraction are assumptions. The analysis validates the allocation
logic against established methods under explicit and widely varied assumptions; card payments are not SME invoices, and
nothing here shows that SME managers behave as assumed. Raw data are not redistributed (see `DATA_SOURCES.md`).

## Archive contents
```
get_data.py, prep.py, rbaa_validate.py, run_all.py, figs.py, paper_tables.py, run_all.sh
RBAA_benchmark_colab.ipynb     Colab wrapper that runs the five steps
outputs/                       archived results, figures, checks, environment.json, MANIFEST.sha256
DATA_SOURCES.md, requirements.txt, CITATION.cff, .zenodo.json, LICENSE (MIT, code only)
```
