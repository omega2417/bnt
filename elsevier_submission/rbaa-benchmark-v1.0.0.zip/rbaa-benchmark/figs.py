import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, sys, json
O=sys.argv[1]
# Figures 2 and 3 of the article, drawn from the result files written by run_all.py (nothing is hard-coded).
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Inter','Arial','DejaVu Sans'],'font.size':9,'axes.spines.top':False,'axes.spines.right':False,
 'axes.edgecolor':'#8a8a85','axes.labelcolor':'#333','xtick.color':'#555','ytick.color':'#555'})
C={'RBAA (load-aware)':'#2a78d6','AI-score alert queue':'#eb6834','Cost-sensitive EL ranking':'#1baf7a',
   'Isolated value-of-review rule':'#eda100','Fixed-accuracy deferral':'#e87ba4','Amount-based approval limit':'#008300'}
LBL={'RBAA (load-aware)':'RBAA (load-aware)','AI-score alert queue':'AI-score queue','Cost-sensitive EL ranking':'Cost-sensitive EL',
   'Isolated value-of-review rule':'Isolated VR rule','Fixed-accuracy deferral':'Fixed-accuracy deferral','Amount-based approval limit':'Amount limit'}
s=pd.read_csv(f'{O}/budget_sweep.csv')
R=json.load(open(f'{O}/summary.json')); N=R['N']
g=pd.read_csv(f'{O}/table_generous.csv').set_index('method').loc['RBAA (load-aware)']
kR,nbR=int(g.reviews),float(g.nb_per_1000)
fig,ax=plt.subplots(figsize=(6.6,4.3),dpi=300)
ax.axhline(0,color='#bbb',lw=0.8)
for m in C:
    d=s[s.method==m]
    ax.plot(d.budget/N*100,d.nb_per_1000,color=C[m],lw=2.6 if m.startswith('RBAA') else 1.6,label=LBL[m],marker='o',ms=3)
ax.set_xscale('log'); ax.set_ylim(-60,102)
ax.set_xticks([0.02,0.05,0.1,0.2,0.5,1,2]); ax.set_xticklabels(['0.02','0.05','0.1','0.2','0.5','1','2'])
ax.set_xlabel('Review budget (% of operations in the stream)'); ax.set_ylabel('Net benefit per 1,000 operations (€)')
ax.grid(axis='y',color='#e6e6e3',lw=0.6)
for x in [R['B1']/N*100,R['B2']/N*100]: ax.axvline(x,color='#999',ls=':',lw=0.8)
ax.text(R['B1']/N*100,101,f"tight budget ({R['B1']}) ",fontsize=7,color='#555',va='top',ha='right')
ax.text(R['B2']/N*100,101,f" generous budget ({R['B2']})",fontsize=7,color='#555',va='top')
ax.plot([kR/N*100],[nbR],marker='D',ms=6,color='#1c5cab',zorder=5)
ax.annotate(f'RBAA stops itself\nat {kR} reviews',xy=(kR/N*100,nbR),xytext=(0.19,90),fontsize=7,color='#1c5cab',arrowprops=dict(arrowstyle='-',color='#1c5cab',lw=0.7))
ax.legend(frameon=False,fontsize=7.5,loc='upper center',bbox_to_anchor=(0.5,-0.17),ncol=3)
fig.tight_layout(); fig.savefig(f'{O}/fig2_budget_sweep.png'); plt.close()

f=pd.read_csv(f'{O}/hard_floor.csv'); f=f[~f.deputy]
t=pd.read_csv(f'{O}/table_generous.csv')
fig,(a1,a2)=plt.subplots(1,2,figsize=(7.2,3.5),dpi=300,gridspec_kw={'width_ratios':[1,1.15]})
Ms=[1000,2000,3000,5000,10000]; x=np.arange(len(Ms)); w=0.38
for i,(om,col,lab) in enumerate([(1.0,'#2a78d6','ω = 1 (full amount lost)'),(0.25,'#eb6834','ω = 0.25')]):
    v=[f[(f.M==M)&(np.isclose(f.omega,om))].cost_of_floor.iloc[0]/1000 for M in Ms]
    a1.bar(x+(i-0.5)*w,v,w*0.92,color=col,label=lab)
    for xi,vi in zip(x,v): a1.text(xi+(i-0.5)*w,vi+0.4,f'{vi:.1f}',ha='center',fontsize=6.5,color='#333')
a1.set_xticks(x); a1.set_xticklabels(['1k','2k','3k','5k','10k']); a1.set_xlabel('Materiality threshold M (€)')
a1.set_ylabel('Cost of the hard floor (€ thousand)'); a1.legend(frameon=False,fontsize=7); a1.set_title('(a) Price of the mandatory-review safeguard',fontsize=8.5,loc='left')
a1.grid(axis='y',color='#e6e6e3',lw=0.6)
order=['RBAA (load-aware)','Isolated value-of-review rule','Fixed-accuracy deferral','Classifier threshold (p≥0.5)','AI-score alert queue','Cost-sensitive EL ranking','Random audit','Amount-based approval limit']
tt=t.set_index('method').loc[order]
lab2=['RBAA','Isolated VR rule','Fixed-accuracy deferral','Classifier p≥0.5','AI-score queue','Cost-sensitive EL','Random audit','Amount limit']
cols=['#2a78d6']+['#9aa3ad']*7
yy=np.arange(len(order))[::-1]
a2.axvline(0,color='#888',lw=0.8)
a2.barh(yy,tt.nb_per_1000.values,color=cols,height=0.62)
for yi,v,h in zip(yy,tt.nb_per_1000.values,tt.hours.values):
    a2.text(v+3 if v>=0 else 3,yi,(f'−€{abs(v):.1f}' if v<0 else f'€{v:.1f}')+f'  ({h:.0f} h)',va='center',fontsize=6.5,color='#333')
a2.set_yticks(yy); a2.set_yticklabels(lab2,fontsize=7.5); a2.set_xlabel('Net benefit per 1,000 operations (€)')
a2.set_title('(b) Net benefit at a 0.5% budget (review hours)',fontsize=8.5,loc='left'); a2.set_xlim(-100,135)
a2.grid(axis='x',color='#e6e6e3',lw=0.6)
fig.tight_layout(); fig.savefig(f'{O}/fig3_economics.png'); plt.close()
