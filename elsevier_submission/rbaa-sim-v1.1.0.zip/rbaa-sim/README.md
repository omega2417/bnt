# rbaa-sim — companion notebook (v1.1.0)

Model-reproduction companion to the article
**"Cognitive optimisation of AI-supported SME decisions through risk-based allocation of managerial attention"**
(Torstensson, Prokopovych-Tkachenko, Britchenko, Ilessova, Chubaievskyi & Merkibaeva; manuscript submitted to
*Digital Business*, Elsevier).

Everything lives in one self-contained notebook, `RBAA_sim_colab.ipynb`. It has no project-specific dependencies and no
data files, and it uses only packages that are pre-installed on Google Colab.

Companion packages: `rbaa-validation` (archived back-test on real open data, Appendix B) and `rbaa-benchmark`
(comparative validation against seven allocation rules, Section 5 and Supplementary Material S1).

## Run it

**Google Colab (recommended)**
1. Open https://colab.research.google.com → *File → Upload notebook* → choose `RBAA_sim_colab.ipynb`.
2. *Runtime → Run all*. A full run takes about one minute. The last code cell downloads `rbaa_outputs.zip`.

**Local Jupyter**
```bash
python -m pip install -r requirements.txt jupyter
jupyter nbconvert --to notebook --execute RBAA_sim_colab.ipynb --output executed.ipynb
```
Outputs are written to `rbaa_outputs/` next to the notebook. The archived run is in `outputs/`.

## Where each result appears in the article

| Notebook § | Content | Article |
|---|---|---|
| 2 | φ(R), expected loss, value of review, routing rule with scope gate and hard floor | Eqs. (1)–(2), Table 2 |
| 3 | Table A1 reproduced; every row checked against the published values; hard floor never reaches Level 4 | Appendix A, Table A1 |
| 4 | Table 7 reproduced (all 24 cells, pooled variance); the unpooled formula differs in 6 cells | Appendix C.7, Table 7 |
| 5 | (A1)–(A2) checked by finite differences; admissible interval where q and h are probabilities; e\* and eₘ for ℓ = 0, 0.5, 1, 2 (0.592/0.592, 0.393/0.534, 0.307/0.485, 0.218/0.404); sensitivity over (ℓ, q₁, h₁); linear, concave and convex q(L) | Eq. (3), Appendix A, **Figure A1** |
| 6 | Synthetic stream of invoices and purchase requests (log-normal amounts, beta error probabilities, month-end peaks) | Appendix C.2, C.6 |
| 7 | Simulation power: validation against Table 7 and type-I error; power for the severity-weighted outcome (baseline-adjusted ANCOVA, restricted wild bootstrap) | Appendix C.7, **Figure A2** |
| 8 | Analysis plan of Appendix C.9 on synthetic trial data: H1a (design-weighted equal-firm estimand, wild bootstrap, randomisation inference; operation-weighted and GLMM secondary), H1b (non-inferiority, 90 % CI), H2a (LMM) and H2b (firm-period minutes per operation; gamma model secondary), Holm; H3a (unverified-error escape rate, autonomous vs human escapes), seeded errors, H3b (Brier, Murphy decomposition); H4 (randomised threshold-policy contrasts; quadratic model secondary and associational; carry-over sensitivity; programmed truth); H5 (firm-level interaction, Johnson–Neyman) | Appendix C.5, C.9, Table 8 |
| 9 | Test report, environment, SHA-256 manifest | — |

The notebook contains 36 checks; all of them passed in the archived run (`outputs/test_report.csv`).

| Output file | Article element |
|---|---|
| `outputs/table_A1.csv` | Table A1 |
| `outputs/table_7.csv` | Table 7 |
| `outputs/appendixA_optima.csv`, `appendixA_finite_difference_check.csv` | Appendix A (e\*, eₘ, derivative check) |
| `outputs/fig_A1_netperformance.png/.pdf` | Figure A1 |
| `outputs/fig_A2_power.png/.pdf`, `sim_power_severity_weighted.csv` | Figure A2 |
| `outputs/table_8_pipeline_synthetic_results.csv` | Table 8 (format only; synthetic data) |

## Changes from v1.0.0

* Article title and journal updated (*Digital Business*, Elsevier); table, figure and section numbers follow the revised
  article (former Table 5 → Table 7; former Table 6 → Table 8; protocol sections → Appendix C).
* Appendix A: e\* and eₘ are computed only on the admissible interval where q(L) and h(L) are probabilities; for ℓ = 2
  the curve ends at e = 0.8. Figure A1 is exported in the form printed in the article, and the optima are checked
  against the printed values.
* Synthetic pipeline aligned with the revised estimands of Appendix C: probability-based outcome audit stratified by
  case complexity with recorded inclusion probabilities and a Horvitz–Thompson estimator (checked against the synthetic
  population); operation-weighted estimand as a labelled secondary analysis; H2b on total managerial time per operation;
  H3a as the unverified-error escape rate with autonomous and human escapes separated; H4 primary analysis by
  randomised threshold-policy contrasts, the quadratic model secondary and without instrumental-variable
  identification; H5 at firm level with workload-weighted competence scores.
* Synthetic generator: case complexity also raises the AI error probability, so that unequal audit inclusion
  probabilities matter for the estimator.

## Assumptions and scope

* All assumptions are set in one `CONFIG` dictionary (§1) and exported to `outputs/config.json`. Values from the article
  are marked *paper*; all others are illustrative assumptions of this package. Change any of them and re-run.
* **No empirical data are included, and nothing here is evidence for H1–H5.** §5–§7 illustrate the model under assumed
  functional forms. §8 uses a synthetic data-generating process, so whatever it "finds" follows from that process and
  from the number of synthetic firms. Its purpose is to show that the planned analysis code runs end-to-end and to
  compare its estimates with the programmed truth. The pipeline will be locked before preregistration of the field study.
* Python stand-ins for the planned R models: the GLMM is `statsmodels` `BinomialBayesMixedGLM` (variational Bayes) with
  a GEE cross-check; the gamma model for positive review durations is a gamma GEE with log link. Wild-bootstrap,
  randomisation-inference and Lind–Mehlum code is implemented directly in the notebook.
* Runs are deterministic for a given seed (`CONFIG["seed"]`) and library versions (`outputs/environment.json`). Other
  library versions may change the last digits of the simulation-based numbers. Table A1, Table 7 and the Appendix A
  optima are exact.

## Archive contents

```
RBAA_sim_colab.ipynb   executed notebook (outputs included; "Run all" regenerates them)
outputs/               results of the archived run: tables (CSV), figures (PNG 300 dpi + PDF), config.json,
                       environment.json, test_report.csv, MANIFEST.sha256
requirements.txt       minimum versions (+ versions tested)
CITATION.cff           software and article citation
.zenodo.json           Zenodo deposit metadata
LICENSE                MIT
```

## Licence

Code: MIT (see `LICENSE`).
